import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'i18n-demo';
    logo: string = 'https://angular.io/assets/images/logos/angular/angular.png';
    minutes = 0;
}
